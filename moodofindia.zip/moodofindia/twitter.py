import json
from datetime import datetime
from datetime import timedelta
import pandas as pd
import requests
# f = open('data/jsondata.txt')
# sentiment_data = json.load(f)

# f = open('data/nat_jsondata.txt')
# sentiment_nat = json.load(f)

url = 'https://api.covid19india.org/csv/latest/state_wise_daily.csv'
r = requests.get(url, allow_redirects=True)

open('state_wise_daily.csv', 'wb').write(r.content)

x = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")

# start = list(sentiment_nat.keys())[0]
start = "2020-03-01"


start_date = datetime.strptime(start, "%Y-%m-%d")
latest = datetime.strptime(x, "%Y-%m-%d")

delta = latest-start_date

date_list_keys = []
total_maps = 0

def emotion_one(lis):
    emo_dict = {'anger': 0, 'disgust': 1, 'joy': 2, 'surprise': 3, 'fear': 4, 'sadness': 5,'neutral':6}
    return emo_dict[lis]

# print(sentiment_nat)
sentiment_nat = {}
sentiment_data = {}

count = 0
count2 = 0

for ii in range(0,delta.days+1):

    from_date = (start_date+timedelta(days=ii)).strftime("%Y-%m-%d")
    print(from_date)
    try:
        data=pd.read_csv('data/data_'+from_date + '.csv')
    except:
        print("couldnt read")
        break
    for i,j in data.iterrows():

        if j['Tweet Posted Time (UTC)'] not in sentiment_data.keys():
            print("Added ", j['Tweet Posted Time (UTC)'])
            sentiment_data[j['Tweet Posted Time (UTC)']] = {}
        
        if j['Tweet Posted Time (UTC)'] not in sentiment_nat.keys():
            sentiment_nat[j['Tweet Posted Time (UTC)']] = [0,0,0,0,0,0,0]
        
        

        
        flag = 0
        
        areLoc = j['Tweet Location'].strip()


        if areLoc == "Visakhapatnam" or areLoc == "Tirupati":
            flag = 1
            areLoc = "Andhra Pradesh"

        if areLoc == "Jaipur":
            flag = 1
            areLoc = "Rajasthan"
        
        if areLoc == "Indore":
            flag = 1
            areLoc = "Madhya Pradesh"

        if areLoc == "Bhubaneswar":
            flag = 1
            areLoc = "Orissa"
        
        if areLoc == "Dehradun":
            flag = 1
            areLoc = "Uttarakhand"
        
        if areLoc == "Kochi":
            flag = 1
            areLoc = "Kerala"
        
        if areLoc == "Ahmedabad":
            flag = 1
            areLoc = "Gujarat"
        
        if areLoc == "Bangalore":
            flag = 1
            areLoc = "Karnataka"

        if areLoc == "Kolkata":
            flag = 1
            areLoc = "West Bengal"

        if areLoc == "Hyderabad":
            flag = 1
            areLoc = "Telangana"

        if areLoc == "Mumbai":
            flag = 1
            areLoc = "Maharashtra"
        
        count+=1

        if areLoc not in sentiment_data[j['Tweet Posted Time (UTC)']]:
            sentiment_data[j['Tweet Posted Time (UTC)']][areLoc] = [0,0,0,0,0,0,0]
        else:
            sentiment_data[j['Tweet Posted Time (UTC)']][areLoc][emotion_one(j['Emotion'])] += 1

        if flag == 1:
            if j['Tweet Location'] not in sentiment_data[j['Tweet Posted Time (UTC)']]:
                sentiment_data[j['Tweet Posted Time (UTC)']][j['Tweet Location']] = [0,0,0,0,0,0,0]
            else:
                sentiment_data[j['Tweet Posted Time (UTC)']][j['Tweet Location']][emotion_one(j['Emotion'])] += 1
        else:
            count2 += 1
            sentiment_nat[j['Tweet Posted Time (UTC)']][emotion_one(j['Emotion'])] += 1

        


print(sentiment_nat)

print(count)
print(count2)

with open('data/jsondata.txt', 'w') as outfile:
    json.dump(sentiment_data, outfile)

with open('data/nat_jsondata.txt', 'w') as outfile:
    json.dump(sentiment_nat, outfile)




        # print(j['Emotion'])
        # print(j['Tweet Location'])
        # print(j['Tweet Posted Time (UTC)'])

    # date_list_keys.append(from_date)
    # total_maps += 1
    # for i,j in data.iterrows():


