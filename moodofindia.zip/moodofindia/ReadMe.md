# To install all the requirements.

> pip install -r requirements.txt

# Run using

> python app.py

# Host anywhere you like

> Earlier hosted on Heroku. The project is setup for Heroku. Will be easier to host on heroku. Look at heroku documentation.

# Code

> Currently it is set to be static.
> The function at line 1013 in main.py is responsible for daily updates currently commented. (Heroku has size limitation) Also uncomment 1025 to 1028
