import nltk
from nltk import TweetTokenizer 
import pandas as pd
import nltk.classify.util
from nltk.classify import NaiveBayesClassifier
from nltk.corpus import movie_reviews

def extract_features(word_list):
    return dict([(word, True) for word in word_list])
 
positive_fileids = movie_reviews.fileids('pos')
negative_fileids = movie_reviews.fileids('neg')

features_positive = [(extract_features(movie_reviews.words(fileids=[f])), 
           'Positive') for f in positive_fileids]

features_negative = [(extract_features(movie_reviews.words(fileids=[f])), 
           'Negative') for f in negative_fileids]

# Split the data into train and test (80/20)
threshold_factor = 0.8
threshold_positive = int(threshold_factor * len(features_positive))
threshold_negative = int(threshold_factor * len(features_negative))

features_train = features_positive[:threshold_positive] + features_negative[:threshold_negative]
features_test = features_positive[threshold_positive:] + features_negative[threshold_negative:]  
print("\nNumber of training datapoints:", len(features_train))
print("Number of test datapoints:", len(features_test))

# Train a Naive Bayes classifier
classifier = NaiveBayesClassifier.train(features_train)
print("\nAccuracy of the classifier:", nltk.classify.util.accuracy(classifier, features_test))

# Sample input reviews
input_reviews = [
    "It is an amazing movie", 
    "This is a dull movie. I would never recommend it to anyone.",
    "The cinematography is pretty great in this movie", 
    "The direction was terrible and the story was all over the place" 
]

negation = ['no',"dont",'do not', 'not', 'never']



from nltk.corpus import wordnet

tk = TweetTokenizer() 


Target = "This is not good."

data=pd.read_csv("emotions.csv")

emo_dict = {}

for i,j in data.iterrows():
    emo = j['emotion']
    if emo not in emo_dict.keys():
        emo_dict[emo] = [j['word']]
    else:
        emo_dict[emo].append(j['word'])

def get_emo_words(sent):
    score = {}
    # tokens = remove_stop_words(sent.split(' '))

    tokens = tk.tokenize(sent)
    tagged = nltk.pos_tag(tokens)
    print(tagged)

    is_neg = False

    for neg in negation:
        if sent.find(neg)!=-1:
            is_neg = True
            print("Is Neg")

    for key in emo_dict.keys():
        score[key] = 0
        compare = emo_dict[key]
        # print(compare)
        for num,i in enumerate(tokens):
            #Creating a list 
            if tagged[num][1] not in ['IN','NN','NNP']:
                synonyms = [i]
                for syn in wordnet.synsets(i):
                    for lm in syn.lemmas():
                            synonyms.append(lm.name())#adding into synonyms
                # print (set(synonyms))
                synonyms = set(synonyms)
                for k in synonyms:
                    if k in compare:
                        score[key] = score[key] + 1
                        print(i,k,key)

    print(score)
    feeling = ""
    maxi = -1
    for key in score.keys():
        if score[key] > maxi:
            maxi = score[key]
            feeling = key
    
    
    opposites = {'anger': 'neutral', 'joy':'sadness', 'surprise':'neutral','fear':'neutral','sadness':'joy'}
    if is_neg:
        print(opposites[feeling])
        return opposites[feeling]
        
    print(feeling)
    return feeling





data=pd.read_csv("tweets_with_emoji.csv")
print(data.head())


# f = open('tweets_with_emoji.csv', 'w', encoding="utf-8")
# f.write('Tweet Posted Time (UTC),Tweet Content,Tweet Location,Emotion\n')
# for i,j in data.iterrows():
#     Target = j['Tweet Content']
#     probdist = classifier.prob_classify(extract_features(Target.split()))
#     pred_sentiment = probdist.max()
#     print("Predicted sentiment:", pred_sentiment) 
#     print("Probability:", round(probdist.prob(pred_sentiment), 2))
#     emo = get_emo_words(Target)
#     f.write(j['Tweet Posted Time (UTC)']+','+j['Tweet Content'].strip().replace('\n',' ').replace(',',' ') + ',' + j['Tweet Location']+','+emo +'\n')


