import GetOldTweets3 as got
from datetime import datetime
from datetime import timedelta
import nltk
from nltk import TweetTokenizer 
import pandas as pd
import nltk.classify.util
from nltk.corpus import wordnet
import os.path
from os import path

def get_emo_words(sent):
        score = {}
        # tokens = remove_stop_words(sent.split(' '))
        tk = TweetTokenizer() 
        tokens = tk.tokenize(sent)
        tagged = nltk.pos_tag(tokens)
        # print(tagged)
        emo_dict = {}
        data=pd.read_csv("emotions.csv")
        for i,j in data.iterrows():
            emo = j['emotion']
            if emo not in emo_dict.keys():
                emo_dict[emo] = [j['word']]
            else:
                emo_dict[emo].append(j['word'])

        is_neg = False
        negation = ['no',"dont",'do not', 'not', 'never']
        for neg in negation:
            if sent.find(neg)!=-1:
                is_neg = True
                print("Is Neg")

        for key in emo_dict.keys():
            score[key] = 0
            compare = emo_dict[key]
            # print(compare)
            for num,i in enumerate(tokens):
                #Creating a list 
                if tagged[num][1] not in ['IN','NN','NNP']:
                    synonyms = [i]
                    for syn in wordnet.synsets(i):
                        for lm in syn.lemmas():
                                synonyms.append(lm.name())#adding into synonyms
                    # print (set(synonyms))
                    synonyms = set(synonyms)
                    for k in synonyms:
                        if k in compare:
                            score[key] = score[key] + 1
                            # print(i,k,key)

        # print(score)
        feeling = ""
        maxi = -1

        was_zero = False
        for key in score.keys():
            if score[key] > maxi:
                if score[key] == 0:
                    was_zero = True
                    maxi = score[key]
                    feeling = key
                else:
                    was_zero = False
                    maxi = score[key]
                    feeling = key
        
        
        opposites = {'anger': 'neutral', 'joy':'sadness', 'surprise':'neutral','fear':'neutral','sadness':'joy','disgust':'disgust'}
        if is_neg:
            # print(opposites[feeling])
            return opposites[feeling]
            
        # print(feeling)
        if was_zero == True:
            return 'neutral'

        return feeling

def ultimate():
    x = datetime(2020,6,14)
    # print((x+timedelta(days=60)).strftime("%Y-%m-%d"))
    states = open("state_codes", encoding='utf-8').readlines()
    states = [i[:-3] for i in states]
    # print(states)
    y = datetime.now()

    delta = y - x
    count = []

    log = open('data/logs','a',encoding='utf-8')
    for ii in range(12):
        min_count = 0
        from_date = (x+timedelta(days=ii)).strftime("%Y-%m-%d")
        to_date = (x+timedelta(days=ii+1)).strftime("%Y-%m-%d")
        
        if path.exists('data/data_'+from_date + '.csv'):
            print("Path exists: Append mode!")
            f = open('data/data_'+from_date + '.csv', 'a', encoding='utf-8')
        else:
            f = open('data/data_'+from_date + '.csv', 'a', encoding='utf-8')
            f.write('Tweet Posted Time (UTC),Tweet Content,Tweet Location,Emotion\n')

        print('Started for all states for the date of ' + from_date)
        log.write('Started for all states for the date of ' + from_date + '\n')
        for s in states:
            if s != "null":
                log.write("Started for State: " + s + "Date: " + from_date+"\n")
                print("Started for State: " + s + "Date: " + from_date+"\n")

                try:
                    tweetCriteria4 = got.manager.TweetCriteria().setQuerySearch("Covid-19")\
                                                        .setLang('en')\
                                                        .setMaxTweets(100)\
                                                        .setNear(s)\
                                                        .setSince(from_date)\
                                                        .setUntil(to_date)
                except:
                    pass

                try:
                    tweetCriteria5 = got.manager.TweetCriteria().setQuerySearch("FightCorona")\
                                                        .setLang('en')\
                                                        .setMaxTweets(100)\
                                                        .setNear(s)\
                                                        .setSince(from_date)\
                                                        .setUntil(to_date)
                except:
                    pass
                
                try:
                    tweetCriteria = got.manager.TweetCriteria().setQuerySearch("coronavirus")\
                                                        .setLang('en')\
                                                        .setMaxTweets(100)\
                                                        .setNear(s)\
                                                        .setSince(from_date)\
                                                        .setUntil(to_date)
                except:
                    pass

                try:
                    tweetCriteria2 = got.manager.TweetCriteria().setQuerySearch("Covid")\
                                                        .setLang('en')\
                                                        .setMaxTweets(100)\
                                                        .setNear(s)\
                                                        .setSince(from_date)\
                                                        .setUntil(to_date)
                except:
                    pass
                
                try:
                    tweetCriteria3 = got.manager.TweetCriteria().setQuerySearch("Lockdown")\
                                                        .setLang('en')\
                                                        .setMaxTweets(100)\
                                                        .setNear(s)\
                                                        .setSince(from_date)\
                                                        .setUntil(to_date)
                except:
                    pass
                
                try:
                    tweet = got.manager.TweetManager.getTweets(tweetCriteria)
                    for i in tweet:
                        print(i)
                        min_count += 1
                        f.write(from_date +","+ i.text.replace(',', ' ') +","+ s.strip() +"," + get_emo_words(i.text.replace(',', ' ')) + '\n' )
                except:
                    print("Can't add")
                    pass
                try:
                    tweet2 = got.manager.TweetManager.getTweets(tweetCriteria2)
                    for i in tweet2:
                        print(i)
                        min_count += 1
                        f.write(from_date +","+ i.text.replace(',', ' ') +","+ s.strip() +"," + get_emo_words(i.text.replace(',', ' ')) + '\n' )
                except:
                    print("Can't add")
                    pass
                
                try:
                    tweet3 = got.manager.TweetManager.getTweets(tweetCriteria3)
                    for i in tweet3:
                        print(i)
                        min_count += 1
                        f.write(from_date +","+ i.text.replace(',', ' ') +","+ s.strip() +"," + get_emo_words(i.text.replace(',', ' ')) + '\n' )
                except:
                    print("Can't add")
                    pass
                try:
                    tweet4 = got.manager.TweetManager.getTweets(tweetCriteria4)
                    for i in tweet4:
                        print(i)
                        min_count += 1
                        f.write(from_date +","+ i.text.replace(',', ' ') +","+ s.strip() +"," + get_emo_words(i.text.replace(',', ' ')) + '\n' )
                except:
                    print("Can't add")
                    pass
                
                try:
                    tweet5 = got.manager.TweetManager.getTweets(tweetCriteria5)
                    for i in tweet5:
                        print(i)
                        min_count += 1
                        f.write(from_date +","+ i.text.replace(',', ' ') +","+ s.strip() +"," + get_emo_words(i.text.replace(',', ' ')) + '\n' )
                except:
                    print("Can't add")
                    pass

                print(s,from_date)
                log.write("State: " + s + "Date: " + from_date+ " --done\n")
        log.write('Completed all states for the date of ' + from_date + '\n')
        print('Completed all states for the date of ' + from_date)

        log.write('Count min: ' +from_date + " " + str(min_count) + '\n')     
        count.append(min_count)
        
        f.close()

    sumi = 0

    for i in count:
        sumi = sumi + i


    log.write('Count Total: ' + str(sumi) + '\n')
    print(count)

ultimate()

                                           

