from flask import Flask, render_template, make_response
import pdfkit

app = Flask(__name__)

@app.route('/')
def pdf():
    res = render_template('report.html', name="Dheeraj")

    response_string = pdfkit.from_string(res, False)

    response = make_response(response_string)


    response.headers['Content-Type'] = 'application/pdf'

    response.headers['Content-Disposition'] = 'inline;filename=report.pdf' 

    return response

if __name__ == '__main__':
    app.run(debug=True)
