import schedule 
import time

def bedtime(): 
    print("It is bed time go rest") 

schedule.every().day.at("23:00").do(bedtime) 

while True:
    schedule.run_pending() 
    time.sleep(1)