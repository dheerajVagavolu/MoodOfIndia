import json
import pandas as pd

with open('data/jsondata.txt') as json_file:
    sentiment_date = json.load(json_file)

print(sentiment_date)

stated = {}

for key in sentiment_date.keys():
    for l in sentiment_date[key].keys():
        if l not in stated.keys():
            stated[l] = sentiment_date[key][l]
        else:
            for num,j in enumerate(sentiment_date[key][l]):
                stated[l][num] += j

print(stated)

f = open('state_codes', encoding='utf-8').readlines()

state_codes = {}
opp_state_codes = {}
for i in f:
    l = i.strip().split(' ')
    fi = i[:-4]
    se = l[-1]
    state_codes[se] = fi
    opp_state_codes[fi] = se

data = pd.read_csv('state_wise_daily.csv', error_bad_lines=False)

data.fillna(0, inplace = True) 

new_dat = {}

print(state_codes)

for i,j in data.iterrows():
    states = list(j.keys())
    print(j[states[1]])
    for i in states[3:]:
        try:
            print(state_codes[i])
            if state_codes[i] not in new_dat.keys():
                new_dat[state_codes[i]] = {"Confirmed":0,"Recovered":0,"Deceased":0}
            
            new_dat[state_codes[i]][j[states[1]]] += j[i] 
        except:
            print("Dont need")

print(new_dat)



f = open('table.txt', 'w',encoding='utf-8')

f.write("State    Anger  Disgust  Joy  Surprise  Fear  Sadness  Neutral  Confirmed  Recovered  Deceased\n")
for i in stated.keys():
    if i in new_dat.keys():
        f.write(i + '  |  ' + str(stated[i][0]) + '  |  ' + str(stated[i][1]) + '  |  ' + str(stated[i][2]) + '  |  ' + str(stated[i][3]) + '  |  ' + str(stated[i][4]) + '  |  ' + str(stated[i][5]) + '  |  ' + str(stated[i][6]) + '  |  '+str(new_dat[i]['Confirmed']) +'  |  '+str(new_dat[i]['Recovered']) +'  |  '+str(new_dat[i]['Deceased']) + '\n')
f.close()
